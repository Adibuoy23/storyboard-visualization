Storyboards fMRI - preprocessed per-participant data
Packaged 2026-10-19 from https://github.com/Adibuoy23/storyboard-visualization

sherlock_storyboards_preprocessed_data.csv
  Retrospective key-moment (storyboard) selections, one row per participant per selected frame
  columns: subjectID, selected_frame, video, Movie+clip_number, num_frames, start, end, duration, selected_frame_time, Part, selected_frame_time_continuous, start_continuous, end_continuous, storyboardClipNo

sherlock_event_boundaries_preprocessed_data.csv
  Realtime event-boundary button presses, one row per participant per press
  columns: bpTime, subid, clipNo, grain, bp, storyboardClipNo, bin
