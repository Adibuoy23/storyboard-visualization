2x2 KM & EB - preprocessed per-participant data
Packaged 2026-10-19 from https://github.com/Adibuoy23/storyboard-visualization

realtime_KM_preprocessed_data.csv
  Realtime key-moment responses
  columns: subjectID, sessionID, selected_frame, video, num_frames, duration, selected_frame_time, start_time, end_time, clipNo, end_time_continuous, start_time_continuous, selected_frame_time_continuous

retrospective_KM_preprocessed_data.csv
  Retrospective key-moment selections
  columns: subjectID, sessionID, selected_frame, video, num_frames, duration, selected_frame_time, start_time, end_time, clipNo, end_time_continuous, start_time_continuous, selected_frame_time_continuous

realtime_EB_preprocessed_data.csv
  Realtime event-boundary button presses
  columns: subjectID, sessionID, selected_frame, video, num_frames, duration, selected_frame_time, start_time, end_time, clipNo, end_time_continuous, start_time_continuous, selected_frame_time_continuous

retrospective_EB_preprocessed_data.csv
  Retrospective event-boundary selections
  columns: subjectID, sessionID, selected_frame, video, num_frames, duration, selected_frame_time, start_time, end_time, clipNo, end_time_continuous, start_time_continuous, selected_frame_time_continuous
