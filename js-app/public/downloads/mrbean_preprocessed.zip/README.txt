Mr. Bean - preprocessed per-participant data
Packaged 2026-10-19 from https://github.com/Adibuoy23/storyboard-visualization

MrBean_storyboards_preprocessed_data.csv
  Retrospective key-moment (storyboard) selections
  columns: subjectID, selected_frame, video, clip_number, num_frames, duration, selected_frame_time, start_time, end_time, start_time_corrected, end_time_corrected, selected_frame_corrected, selected_frame_time_corrected, selected_frame_time_continuous
